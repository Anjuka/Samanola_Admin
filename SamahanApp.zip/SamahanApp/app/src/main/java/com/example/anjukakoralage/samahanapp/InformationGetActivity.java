package com.example.anjukakoralage.samahanapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Locale;

/* Design & Developed By Anjuka Dulan Koralage */

public class InformationGetActivity extends AppCompatActivity {

    private ImageView btnSubmite;
    private ImageButton btnBack;
    private EditText etName, etMobile, etEmail;
    private String Name, Mobile, Email;
    private ProgressDialog pDialog;
    private JSONObject saveObject;
    private JSONObject smsObject;
    private static final String TAG = InformationGetActivity.class.getSimpleName();
    private ImageView imgDetailAdd, ivName, ivTP, ivEmail;
    private ImageButton btnCapture;
    private Bitmap bmp2;
    private RoundedImageView ivUserImage;
    private byte[] byteArray;
    private  Bitmap bitmap, bitmap1 ;
    private SharedPreferences shre;
    private  Bitmap bmp;
    private String imageeeeee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        // startService(new Intent(this, MuService.class));
        String CurrentLang = Locale.getDefault().getLanguage();
        setContentView(R.layout.activity_information_get);

      //  ivUserImage = (RoundedImageView) findViewById(R.id.ivUserImage);


      //  System.out.println("============> save string " + previouslyEncodedImage);


       /* if( !previouslyEncodedImage.equalsIgnoreCase("") ){

            byte[] b = Base64.decode(previouslyEncodedImage, Base64.DEFAULT);
            bitmap1 = BitmapFactory.decodeByteArray(b, 0, b.length);

            imageeeeee = b.toString();


        }*/



        imgDetailAdd = (ImageView) findViewById(R.id.imgDetailAdd);
        btnBack = (ImageButton) findViewById(R.id.btnBack);
        btnCapture = (ImageButton) findViewById(R.id.btnCapture);
        ivName = (ImageView) findViewById(R.id.ivName);
        ivTP = (ImageView) findViewById(R.id.ivTP);
        ivEmail = (ImageView) findViewById(R.id.ivEmail);
        btnSubmite = (ImageView) findViewById(R.id.btnSubmite);


        if (CurrentLang.equalsIgnoreCase("si")) {
            imgDetailAdd.setImageResource(R.drawable.details_sinhala);
            ivName.setImageResource(R.drawable.name_sinhala);
            ivTP.setImageResource(R.drawable.tp_no_sinhala);
            ivEmail.setImageResource(R.drawable.email_sinhala);
            btnSubmite.setImageResource(R.drawable.send_sinhala);

        }
        if (CurrentLang.equalsIgnoreCase("ta")) {
            imgDetailAdd.setImageResource(R.drawable.details_tamil);
            ivName.setImageResource(R.drawable.name_tamil);
            ivTP.setImageResource(R.drawable.tp_no_tamil);
            ivEmail.setImageResource(R.drawable.email_tamil);
            btnSubmite.setImageResource(R.drawable.send_tamil);

        }
        if (CurrentLang.equalsIgnoreCase("en")) {
            imgDetailAdd.setImageResource(R.drawable.details_english);
            ivName.setImageResource(R.drawable.name_english);
            ivTP.setImageResource(R.drawable.tp_no_english);
            ivEmail.setImageResource(R.drawable.email_english);
            btnSubmite.setImageResource(R.drawable.send_english);

        }


        etName = (EditText) findViewById(R.id.etName);
        etMobile = (EditText) findViewById(R.id.etMobile);
        etEmail = (EditText) findViewById(R.id.etEmail);


     //   shre.edit().clear().apply();
     // etEmail.setText(previouslyEncodedImage);

        btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  sendSms();
                Intent intent = new Intent(getApplicationContext(), Pop.class);
                startActivity(intent);
            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });


        btnSubmite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

                final String previouslyEncodedImage = shre.getString("image_data", "");

                Name = etName.getText().toString();
                Mobile = etMobile.getText().toString();
                Email = etEmail.getText().toString();


                // sendSms();

                if (Mobile.length() != 10) {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Please enter valid number ", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }

                if (Name.equalsIgnoreCase("")) {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Please enter you name", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
                else if(Mobile.length() != 10) {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Please enter valid number ", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }

                    else {
                    saveObject = new JSONObject();

                    showPDialog();
                    try {
                        saveObject.put("name", Name);
                        saveObject.put("phoneNo", Mobile);
                        saveObject.put("email", Email);
                        saveObject.put("image", previouslyEncodedImage);
                        saveObject.put("phoneString", "PhoneVal");

                    } catch (JSONException e) {
                        hidePDialog();
                    }

                    SaveAPI();


                }
            }
        });

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

/*
    public String sendSms() {
        try {
            // Construct data
            String apiKey = "apikey=" + URLEncoder.encode("oCzPyKoGZxE-2hWrYXp4CB6humJWCiDiz4gyhl4qTs", "UTF-8");
            String message = "&message=" + URLEncoder.encode("This is your message", "UTF-8");
            String sender = "&sender=" + URLEncoder.encode("Link Samahan", "UTF-8");
            String numbers = "&numbers=" + URLEncoder.encode("+94715170929", "UTF-8");

            // Send data
            String data = "https://api.txtlocal.com/send/?" + apiKey + numbers + message + sender;
            URL url = new URL(data);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);

            // Get the response
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            String sResult="";
            while ((line = rd.readLine()) != null) {
                // Process line...
                sResult=sResult+line+" ";
            }
            rd.close();

            return sResult;
        } catch (Exception e) {
            System.out.println("Error SMS "+e);
            return "Error "+e;
        }
    }
*/

    public String BitMapToString(Bitmap bitmap){
        ByteArrayOutputStream baos=new  ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);
        byte [] b=baos.toByteArray();
        String temp=Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    private void SaveAPI() {

        String URLHead = getResources().getString(R.string.url_head_string);
        String saveURL = URLHead + "api/profile";

        JsonObjectRequest SaveDetails = new JsonObjectRequest(Request.Method.POST, saveURL, saveObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(final JSONObject response) {
                hidePDialog();
                try {
                    if (!response.getString("data").isEmpty()) {

                        Snackbar.make(findViewById(android.R.id.content), ApplicationConstants.SAVED_SUCCESS, Snackbar.LENGTH_LONG).show();
                        //shre.edit().clear().apply(); /*<--------------------- Clear*/
                        Intent intent = new Intent(getApplicationContext(), ThankyouActivity.class);
                        startActivity(intent);

                    } else {
                        hidePDialog();
                        Snackbar.make(findViewById(android.R.id.content), ApplicationConstants.SAVE_FAILED, Snackbar.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    hidePDialog();
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), ApplicationConstants.ERROR_MSG_GENERAL, Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                hidePDialog();
                if (volleyError instanceof NetworkError) {
                    Snackbar snackbar = Snackbar
                            .make(findViewById(android.R.id.content), ApplicationConstants.ERROR_MSG_NETWORK, Snackbar.LENGTH_LONG);
                    snackbar.show();
                } else if (volleyError instanceof TimeoutError) {
                    Snackbar snackbar = Snackbar
                            .make(findViewById(android.R.id.content), ApplicationConstants.ERROR_MSG_NETWORK_TIMEOUT, Snackbar.LENGTH_LONG);
                    snackbar.show();
                } else {
                    Snackbar snackbar = Snackbar
                            .make(findViewById(android.R.id.content), ApplicationConstants.ERROR_MSG_GENERAL, Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        });
        SaveDetails.setRetryPolicy(new DefaultRetryPolicy(25000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        AppController.getInstance().addToRequestQueue(SaveDetails);
    }



    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", lang);
        editor.apply();
    }


    //get language from preference
    public void loadLocale() {
        SharedPreferences prefs = getSharedPreferences("Settings", Activity.MODE_PRIVATE);
        String language = prefs.getString("My_Lang", "");
        setLocale(language);
    }

    /*public void checkNetwork(){
        if (haveNetwork()){

            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Device is online", Snackbar.LENGTH_LONG);
            snackbar.show();

        }
        else if (!haveNetwork()){

            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Device is offline", Snackbar.LENGTH_LONG);
            snackbar.show();
        }
    }*/

    private boolean haveNetwork() {

        boolean have_WIFI = false;
        boolean have_MobileData = false;

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo[] networkInfos = connectivityManager.getAllNetworkInfo();

        for (NetworkInfo info : networkInfos) {
            if (info.getTypeName().equalsIgnoreCase("WIFI"))
                if (info.isConnected())
                    have_WIFI = true;

            if (info.getTypeName().equalsIgnoreCase("MOBILE"))
                if (info.isConnected())
                    have_MobileData = true;

        }
        return have_MobileData || have_WIFI;

    }

    private void showPDialog() {
        pDialog = new ProgressDialog(InformationGetActivity.this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Loading, Please wait...");
        pDialog.show();
    }

    private void hidePDialog() {
        if (pDialog != null) {
            pDialog.dismiss();
            pDialog = null;
        }
    }


}
