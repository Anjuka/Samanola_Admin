package com.example.anjukakoralage.samahanapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ViewFlipper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

/* Design & Developed By Anjuka Dulan Koralage */

public class MainActivity extends AppCompatActivity {

    Button btnSinhala, btnTamil, btnEnglish;
    ViewFlipper v_flipper;
    MediaPlayer player;
    private RecyclerView rv;
    private LinearLayoutManager llm;
    private LinearLayout llRe;
    private CoordinatorLayout coordinatorLayout;
    private HashMap<String, String> LoggedUser;
    private HashMap<String, String> UserSettings;
    private ArrayList<HashMap<String, String>> alRegisterItems;
    private TextView tvTotalCount;
    private int page = 0;
    private Switch scShowMyProjects;
    private ProgressDialog pDialog;
    private TextView tvTotalPledge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        setContentView(R.layout.activity_main);

        //GetRegisterData();




     /*   player = MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);

        if (player.isPlaying()) {
            player.stop();
        }



        player.setLooping(true);
        player.start();*/

        btnSinhala = (Button) findViewById(R.id.btnSinhala);
        btnTamil = (Button) findViewById(R.id.btnTamil);
        btnEnglish = (Button) findViewById(R.id.btnEnglish);
     //   tvTotalPledge = (TextView) findViewById(R.id.tvTotalPledge);

        /*ShimmerFrameLayout container =
                (ShimmerFrameLayout) findViewById(R.id.shimmer_view_container);
        container.startShimmer();
*/

        int images[] = {R.drawable.one, R.drawable.two, R.drawable.three, R.drawable.four, R.drawable.five, R.drawable.six, R.drawable.seven, R.drawable.eight};

        v_flipper = (ViewFlipper) findViewById(R.id.v_flipper);

        for (int image : images) {
            flipperImages(image);
        }


        btnSinhala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLocale("si");
                // recreate();
                Intent intent = new Intent(getApplicationContext(), PladgeActivity.class);
              //  startActivity(intent);
            }
        });

        btnEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLocale("en");
                //recreate();
                Intent intent = new Intent(getApplicationContext(), PladgeActivity.class);
               // startActivity(intent);
            }
        });

        btnTamil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLocale("ta");
                //recreate();
                Intent intent = new Intent(getApplicationContext(), PladgeActivity.class);
                //startActivity(intent);
            }
        });

    }

    public void flipperImages(int image) {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(image);

        v_flipper.addView(imageView);
        v_flipper.setFlipInterval(5000);
        v_flipper.setAutoStart(true);

        v_flipper.setInAnimation(this, android.R.anim.fade_in);

    }

    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", lang);
        editor.apply();
    }

    //get language from preference
    public void loadLocale() {
        SharedPreferences prefs = getSharedPreferences("Settings", Activity.MODE_PRIVATE);
        String language = prefs.getString("My_Lang", "");
        setLocale(language);
    }

    private void showPDialog() {
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Loading, Please wait...");
        pDialog.show();
    }

    private void hidePDialog() {
        if (pDialog != null) {
            pDialog.dismiss();
            pDialog = null;
        }
    }



}

