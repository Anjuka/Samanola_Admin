package com.example.anjukakoralage.samahanapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class Pop_second extends AppCompatActivity {

    private ImageView ivCpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_second);


        ivCpa = (ImageView) findViewById(R.id.ivCpa);


    }
}
