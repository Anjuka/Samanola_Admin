package com.example.anjukakoralage.samahanapp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.anjukakoralage.samahanapp.util.RequestPermissionHandler;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.Locale;

/* Design & Developed By Anjuka Dulan Koralage */

public class Pop extends AppCompatActivity {

    private View main;
    WebView webV;
    private ImageView btnCapture;
    private ImageView ivCpa;
    private RequestPermissionHandler mRequestPermissionHandler;
    private  Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        String CurrentLang = Locale.getDefault().getLanguage();
        setContentView(R.layout.activity_pop);

        mRequestPermissionHandler = new RequestPermissionHandler();

        webV = (WebView) findViewById(R.id.webV);
        btnCapture = (ImageView) findViewById(R.id.btnCapture);
        ivCpa = (ImageView) findViewById(R.id.ivCpa);

        if (CurrentLang.equalsIgnoreCase("si")){
            btnCapture.setImageResource(R.drawable.cam_sinhala);

        }
        if (CurrentLang.equalsIgnoreCase("ta")){
            btnCapture.setImageResource(R.drawable.cam_tamil);

        }
        if (CurrentLang.equalsIgnoreCase("en")){
            btnCapture.setImageResource(R.drawable.cam_english);


        }

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;

        getWindow().setLayout((int)(width*.8), (int)(height*.6));


        webV.setWebViewClient(new WebViewClient());
        webV.getSettings();
        webV.setBackgroundColor(Color.BLACK);
       // webV.getSettings().setJavaScriptEnabled(true);
        webV.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        //webV.setHttpAuthUsernamePassword("192.168.8.104", "", "samahan", "12345");
        // webV.loadUrl("http://samahan:12345@192.168.8.104:8080/shot.jpg");

        webV.loadUrl("http://samahan:12345@192.168.43.1:8080/browserfs.html");


       /* btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
finish();
            }
        });*/

       handleButtonClicked();

/*
btnCapture.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        //finish();
        takeScreenshot();
    }
});
*/

    }

    private void handleButtonClicked(){
        mRequestPermissionHandler.requestPermission(this, new String[] {
                Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR
        }, 123, new RequestPermissionHandler.RequestPermissionListener() {
            @Override
            public void onSuccess() {
                Toast.makeText(Pop.this, "request permission success", Toast.LENGTH_SHORT).show();

                btnCapture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        takeScreenshot();

                    //     finish();  /*<-------Changed*/


                    }
                });


            }

            @Override
            public void onFailed() {
                Toast.makeText(Pop.this, "request permission failed", Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", lang);
        editor.apply();
    }


    //get language from preference
    public void loadLocale() {
        SharedPreferences prefs = getSharedPreferences("Settings", Activity.MODE_PRIVATE);
        String language = prefs.getString("My_Lang", "");
        setLocale(language);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mRequestPermissionHandler.onRequestPermissionsResult(requestCode, permissions,
                grantResults);
    }


    private void takeScreenshot() {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            String mPath = Environment.getExternalStorageDirectory().toString() + "/" + now + ".jpeg";

            // create bitmap screen capture
                       View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            v1.buildDrawingCache(true);
            bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            File imageFile = new File(mPath);


            //Bitmap bm = BitmapFactory.decodeFile(mPath);

           // Bitmap bm = BitmapFactory.decodeFile(mPath);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
            byte[] byteArrayImage = baos.toByteArray();
            String encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);


            //setting screenshot in imageview
          //  String filePath = imageFile.getPath();


           // Bitmap ssbitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
            Toast.makeText(this, "Your Picture Captured Successfully", Toast.LENGTH_LONG).show();
            // ivCpa.setImageBitmap(ssbitmap);
            System.out.println("==============================> wadunooooooo");
            // sharePath = filePath;

          /*  ByteArrayOutputStream stream = new ByteArrayOutputStream();
            ssbitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] byteArray = stream.toByteArray();
*/

            System.out.println("======================== encode " + encodedImage);

            // textEncode.setText(encodedImage);

            SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor edit=shre.edit();
            edit.putString("image_data",encodedImage);
            edit.commit();
            finish();
            //  startActivity(in1);

        } catch (Throwable e) {
            // Several error may come out with file handling or DOM

            System.out.println("==============================> Error: "+ e.toString());
            e.printStackTrace();
        }
    }


}
